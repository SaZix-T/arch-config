# Это хранилище моих заметок для Obsidian
![[README 2024-01-01 20.03.00.excalidraw]]
