То же самое что в [[Python]] `for i in a`

``` C++
#include <iostream>
#include <string>

using namespace std;

int main() {
    string line;
    getline(cin, line); //считывает пока не получит "\n"
    for (char symbol : line) {
        cout << symbol << "\t" << static_cast<int>(symbol) << endl; 
        //static_cast преобразует один тип данных в другой (str в int в этом коде)
    }
}
```

[[C++]]