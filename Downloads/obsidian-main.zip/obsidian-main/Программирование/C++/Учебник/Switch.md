То же самое что и if, но сразу переходит к нужному значению, а не от первого до последнего
Поэтому в конце кажлого кейса надо писать `break;`

Можно делать вложенные кейсы 
Так можно совершать одно и то же действие в разных случаях

Пример простого калькулятора с использованием switch
``` C++
#include <iostream>

using namespace std;

int main() {
    int a, b;
    char operation;
    cin >> a >> operation >> b;
 
    int result;
    switch (operation) {
        case '+':
            result = a + b;
            break;
        case '-':
            result = a - b;
            break;
        case '*':
            result = a * b;
            break;
        case '/':
        case ':':
            result = a / b;
            break;
        case '%':
            result = a % b;
            break;
        default:
            result = 0;
    }
 
    std::cout << result << "\n";
}
```

[[C++]]