Позоляет узнать переменной в [[C++]]

Примеры:
``` C++
int main() {
    std::cout << sizeof(char) << endl;        //  1
    std::cout << sizeof(bool) << endl;        //  1
    std::cout << sizeof(short int) << endl;   //  2 (по стандарту >= 2)
    std::cout << sizeof(int) << endl;         //  4 (по стандарту >= 2)
    std::cout << sizeof(long int) << endl;    //  8 (по стандарту >= 4)
    std::cout << sizeof(long long) << endl;   //  8 (по стандарту >= 8)
    std::cout << sizeof(float) << endl;       //  4
    std::cout << sizeof(double) << endl;      //  8
    std::cout << sizeof(long double) << endl; // 16
    
    return 0;
}
```

[[Программирование]]