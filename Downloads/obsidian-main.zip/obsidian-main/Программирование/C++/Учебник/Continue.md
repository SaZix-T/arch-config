Перепрыгивает на следующую итерацию цикла

Пример программы которая выводит только нечетные числа
``` C++
#include <iostream>

using namespace std;

int main() {
    for(int i=0; i<10; i++)
    {
        if(i % 2 == 0) continue;
        cout << i;
    }
}
```

[[C++]]