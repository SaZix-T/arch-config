В [[C++]] можно запустить цикл while до тех пор пока на вход постпают данные

Программа выводит квадраты полученных чисел пока данные вводятся
``` C++
#include <iostream>

using namespace std;

int main() {
    int a;
    while(cin >> a)
    {
        cout << a * a << endl;
    }
}
```