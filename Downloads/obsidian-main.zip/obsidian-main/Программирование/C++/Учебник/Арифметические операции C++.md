Бинарные операции +, - и * работают для чисел стандартным образом
Результат операции деления /, применённой к целым числам, всегда округляется в сторону нуля
Остаток от деления целых чисел можно получить с помощью операции %

Строки (string) можно складывать:
``` C++
#include <iostream>
#include <string>

using namespace std;

int main() {
    string a = "Hello, ";
    string b = "world!";
    string c = a + b;  // Hello, world! 
    
    return 0;
}
```

И можно сразц приравнивать как в [[Python]]:
``` C++
#include <iostream>

int main() {
    int x = 5;
    x += 3;  // x = x + 3
    x *= x;  // x = x * x 
    
    return 0;
}
```

[[Программирование]]