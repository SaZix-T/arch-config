F-stirng: formatted string - форматированная строка
Появились в [[Python]] 3.6
Берут значение имеющихся перемнных и подставляют их в указанное в строке место при выводе

Например вывод значений двух переменных:
``` python
name = "Max"
age = 22

print(f"Hello, {name}! You're {age} years old.")
#Hello, Max! You're 22 years old.
```

Или же матемтическая операция умножения:
``` python
print(f"{2 * 21}") #42
```

Так же поддерживают и форматирование чисел:
```python
p = 3,1415926535
print(f"Значение числа pi: {p:.2f}") #3.14
```

Можно обращаться и к спискам:
```python
planets = ["Меркурий", "Венера", "Земля", "Марс"]
print(f"Планета {planets[2]}") #Планета Земля
```

В f-строках можно вызывать методы объектов:
```python
text = "something"
print(f"{text.upper()}") #SOMETHING
```

Еще можно вызывать [[Функции|функции]]:
```python
def reverse(n):
    return "rev = " + n[::-1]
    
str = "string"
print(f"output: {reverse(str)}") #output: rev = gnirts
```

[[Программирование]]