Работает на языке программирования [[JavaScript]]

**if** и **for** как в С но можно написать for как в python 
``` JavaScript
let a = "abc"
for(i in a)
{
	log(a[i]) // a b c
}
```
``` JavaScript
let a = false
if(a)
{
	log("a is true")
}
else
{
	log("a is false")
}
```

**let** - создать переменную со значением
``` JavaScript
let b = 5
log(b) //5
```

Функции пишутся через `.` например 
``` JavaScript
Console.log("Hello, world!")
Console.warn("Hello, world!")
Console.error("Hello, world!")
```

При создании указателя на что-либо надо писать `const` например
``` JavaScript
const dev = Device
```
А при конструировании чего-то нового писать `new` например
``` JavaScript
const alert = new Alert()
```

Пример создания и вывода предупреждения
``` JavaScript
const alert = new Alert()
alert.message = "Message"
alert.title = "Title"
alert.addAction = "New action"
alert.addAction = "Another action"
alert.addCancelAction = "Cancel action"
alert.addDestructiveAction = "Destructive action"
alert.presentAlert()
```

Пример создания и вывода уведомления
``` JavaScript
const notif = new Notification()
alert.title = "Title"
alert.subitle = "Subitle"
alert.message = "Message"
notif.shedule()
```

- **Device** - можество сведений о девайсе(в документации все расписанно)
- **Safari** - возможность открывать веб сайты в сафари, в приложении на весь экран, в приложении не на весь экран
- **Dictation** - расшифровка голоса в текст, одна функция - start(locale), locale - язык, можно узнать из Device
- **Speech** - проговаривает текст, одная функция - speak(text)
- **DatePiker** - все что связанно с датой
	``` JavaScript
	let dateTime = new Date()
	log(dateTime)
	```

[[Программирование]]